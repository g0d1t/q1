﻿#--------------------------------------------------------------------------|Variebels For Api
API_ID =13291546                                                          #-|
API_HASH = '91b08c777c23cfffd7597d472b41bcb0'                           #-|
BOT_TOKEN= '6951815880:AAHB6YfgI6Oyervpe3t6ENtQgdW-0aO5xCQ'              #-| 
OWNER= 6812092996                                                        #-|
OWNER_USERNAME='lDIRANI'                                  #-|
#--------------------------------------------------------------------------| Robot Variebels
Banners_Channel='@HackScript'
#-----------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------
AndroidPhone = ['Samsung Galaxy A20s', 'Samsung Galaxy A70', 'Samsung Galaxy A01', 'Samsung Galaxy A20','Samsung Galaxy A30s', 'Samsung Galaxy A51', 'Samsung Galaxy A21s', 'Samsung Galaxy A32','Samsung Galaxy A12', 'Xiaomi Poco X3 Pro ', 'Xiaomi Redmi Note 8 pro', 'Xiaomi Poco X3 Pro ','Xiaomi Redmi Note 8', 'Xiaomi Redmi Note 9 Pro', 'Xiaomi Redmi Note 9', 'Xiaomi Poco F3','Huawei Y7 Prime 2019', 'Huawei Y9 Prime 2019', 'Huawei Y6 Prime 2019 ', 'Huawei Honor 10','Asus ROG Phone 5s', 'Asus Zenfone 3 Deluxe']
IosPhone=['iPhone 4S', 'iPhone 5', 'iPhone 5c', 'iPhone 5s', 'iPhone 6', 'iPhone 6 Plus', 'iPhone 6s', 'iPhone 6s Plus', 'iPhone 7', 'iPhone 7 Plus', 'iPhone 8', 'iPhone 8 Plus', 'iPhone X', 'iPhone XR', 'iPhone XS', 'iPhone XS Max', 'iPhone 11', 'iPhone 11 Pro', 'iPhone 11 Pro Max', 'iPhone SE ', 'iPhone 12 mini', 'iPhone 12', 'iPhone 12 Pro', 'iPhone 12 Pro Max', 'iPhone 13 mini', 'iPhone 13', 'iPhone 13 Pro', 'iPhone 13 Pro Max', 'Galaxy S22 Ultra', 'Galaxy S22 ', 'Galaxy Tab S8 ', 'Galaxy A53 5G', 'Galaxy Z Fold3 5g', 'Galaxy Z Flip3 5g', 'Galaxy S21 FE ']
AppVersion = [7.84, 1.18, 8.54, 4.61, 20.01, 3.02, 2.19, 9.10, 6.84, 12.5, 5.12, 5.14, 2.12]
lan = ['AF', 'AL', 'AM', 'AR', 'AU', 'AT', 'AZ', 'BH', 'BY', 'BE', 'BO', 'BR', 'BG', 'CA', 'CR', 'HR', 'CU', 'CY', 'CZ','DK', 'EG', 'FI', 'FR', 'GE', 'DE', 'GR', 'HK', 'HU', 'IN', 'ID', 'IR', 'IQ', 'IE', 'IT', 'JP', 'KW', 'LB', 'MY','MX', 'NL', 'OM', 'PK', 'PS', 'PE', 'PH', 'PL', 'PT', 'CH', 'QA', 'RO', 'RU', 'SA', 'ZA', 'ES', 'CH', 'SY', 'TJ','TH', 'TN', 'TR', 'UA', 'AE', 'UK', 'US', 'UZ', 'VN']
AndroidVersion = [9.0, 10.2, 9.1, 10.21, 9.2, 10.22, 9.3, 10.23, 9.4, 10.24, 9.5, 10.25, 9.6, 10.26, 9.7, 10.27, 9.8,10.28, 9.9, 10.29, 10.0, 10.3, 10.1, 10.31, 10.2, 10.32, 10.3, 10.33, 10.4, 10.34, 10.5, 10.35, 10.6,10.36, 10.7, 10.37, 10.8, 10.38, 10.9, 10.39, 11.0, 10.4, 11.1, 10.41, 11.2, 10.42]
IosVersion = ['iOS 12.0', 'iOS 12.4', 'iOS 12.55', 'iOS 13.0', 'iOS 13.18', 'iOS 14.01', 'iOS 15.0', 'iOS 15.01']
PcVersion = ['Windows 7', 'Windows 8', 'Windows 8.1', 'Windows 8.2', 'Windows 10', 'Windows 10.1', 'Windows 11']


#-----------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------
API=[['XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',1111111111],['XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',11111111111],['XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',1111111111]]
BOT_USERNAME='QRGODBOT'
Photos_Path=r'/root/Advertiser/Data/Fake_Details/Photos'
Fake_Details_Path=r'/root/Advertiser/Data/Fake_Details'
Sessions=r'/root/Advertiser/Sessions'
Dark_Channel='HackScript'
Natural_Channels=[ '@HackScript'] #,'HackScript' , 'HackScript' , 'HackScript'] you can add any channels
#--------------------------------------------------------------------------| Prices
Adding_Account=-30
Delete_Account=-4
Start_Robot=-14
Status=-4
J_L=-4
update_profile=-5
Clean=-2
Attack=-20
Add=-20
Photo=-7
Bio_Name=-5
Spam=-3
Chatcher=-3
report=-7
reaction = -4
block=-4
like=-4
seen=-3
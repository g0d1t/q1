![SQLite](https://img.shields.io/badge/sqlite-%2307405e.svg?style=for-the-badge&logo=sqlite&logoColor=white) ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54) [![GitHub license](https://img.shields.io/github/license/amiralirj/DarkAdvertizer.svg)](https://github.com/amiralirj/DarkAdvertizer/blob/master/LICENSE)
-
[![GitHub forks](https://img.shields.io/github/forks/amiralirj/DarkAdvertizer.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/amiralirj/DarkAdvertizer/network/)

[![GitHub stars](https://img.shields.io/github/stars/amiralirj/DarkAdvertizer.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/amiralirj/DarkAdvertizer/stargazers/)
# Account Receiver 🔥
# DarkAdvertizer 🌪
- 🔱 A bot for advertising and control accounts in TELEGRAM 🔱
- 🔱 SAVE YOUR ACCOUNT IN ROBOT SAFELY 🔱
## Features ⚡️
   - 🔥 Sending BANNERS IN PRIVATE CHAT 📨
   - 🔥 STARTING ROBOT WITH REFERAL ID 🤖
   - 🔥 DELETING & CLEAR CHATS WHICH ARE ANNOYABLE  > ROBOTS & PV & CHANNELS & GROUPS 
   - 🔥 SET FAKE PERSONALITY FOR ACCOUNTS >  SET PHOTO & BIO & USERNAME & NAME 
   - 🔥 COLLECTING USERS USERNAMES THAT ARE IN A GROUP 👥
   - 🔥 AIRDROP FACILITIES > START AND SEND CAPTCHA > ADDING REFFERALS 🚁
   - JOIN & LEAVE CHANNELS & GROUPS ❄️
   - CHECK ACCOUNT STATUS 🔴 🟡 🟢
   - GET ACCOUNT API AUTOMATICALLY 🔁
   - SPAMMING IN GROUPS 📨
   - SENDING REACTIONS 🤪
   - BLOCK & UNBLOCK USER WITH ALL ACOUNTS 🔒 🔓
   - REPORT CHANNEL OR USER 📳
   - OTHER FACILITIES ...
## How To Install/Use  ⚙️
- ### Setting up files
    - Clone or download the repository : `git clone https://github.com/amiralirj/DarkAdvertizer.git`
    - Edit Config»Info `__init__.py` , Replace optional path to save databases there  
        - Replace your API > ApiID/ApiHash <  [Get them from [Here](https://my.telegram.org/)]
        - REPLACE OTHER VARIABLEs 
- ### Installing requirements
    - Install required packages using `pip install -U -r requirements.txt`
    - Start The Bot : `python __main__.py`
    - pyromod==V1.5 , pyrogram V2.056
    - robot should be admin on banner channel (Banners_Channel) and main channel (Dark_Channel)
    - Advertise :) 
